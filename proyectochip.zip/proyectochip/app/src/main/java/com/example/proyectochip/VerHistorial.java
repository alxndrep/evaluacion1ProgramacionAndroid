package com.example.proyectochip;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class VerHistorial extends AppCompatActivity {

    RecyclerView recyclerRegistros;
    AdaptadorRegistros adaptador;
    java.util.ArrayList<Registros> viajes;
    Button btnVolver;
    Usuario user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ver_historial);
        user = (Usuario) getIntent().getSerializableExtra("usuario");
        inicializar();
        btnVolver = findViewById(R.id.btnDevolverVH);


    }

    private void inicializar(){
        recyclerRegistros = findViewById(R.id.historialViajes);
        recyclerRegistros.setLayoutManager(new LinearLayoutManager(this));

        llenarViajes();
        adaptador = new AdaptadorRegistros(viajes);
        recyclerRegistros.setAdapter(adaptador);
    }

    private void llenarViajes(){
        viajes = user.getTarjeta().getHistorial();
    }

    public void devolver(View view) {
        Intent actividadabrirmenu= new Intent(this, MainActivity.class);
        actividadabrirmenu.putExtra("usuario", this.user);
        startActivity(actividadabrirmenu);
    }
}