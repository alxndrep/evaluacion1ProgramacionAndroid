package com.example.proyectochip;

import java.io.Serializable;
import java.util.Date;
import java.util.Random;

public class Registros implements Serializable {

    private Date hora;
    private int valorPasaje;
    private int codigoSerie;
    private String tipoTransporte;

    public Registros(Date hora, String tipoTransporte, int valorPasaje ){
        this.hora = hora;
        Random rand = new Random();
        this.codigoSerie = rand.nextInt(99999) + 999 ;
        this.valorPasaje = valorPasaje;
        this.tipoTransporte = tipoTransporte;
    }

    @Override
    public String toString() {
        return "Registros{" +
                "hora=" + hora +
                ", valorPasaje=" + valorPasaje +
                ", codigoSerie=" + codigoSerie +
                '}';
    }
    public int getValorPasaje(){
        return this.valorPasaje;
    }

    public Date getHora() {
        return hora;
    }

    public int getCodigoSerie() {
        return codigoSerie;
    }

    public String getTipoTransporte() {
        return tipoTransporte;
    }
}
