package com.example.proyectochip;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;

public class Abrir_Tarjeta extends AppCompatActivity {

    EditText inputNombre, inputRut, inputSaldo;
    Button btnGuardar;
    TextView txtNombre, txtRut, txtLabel, txtLabel2;
    private Usuario user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abrir_tarjeta);

        inputNombre = findViewById(R.id.inputNombre);
        inputRut = findViewById(R.id.inputRut);
        inputSaldo = findViewById(R.id.inputNumber);
        btnGuardar = findViewById(R.id.btnGuardar);
        txtNombre = findViewById(R.id.txtNombre);
        txtRut = findViewById(R.id.txtRut);
        txtLabel = findViewById(R.id.label1);
        txtLabel2 = findViewById(R.id.label2);

    }

    public void crearTarjeta(View view) {
        int tempSaldo;
        if(inputSaldo.getText().toString().equals("")){
            tempSaldo = 0;
        }else{
            tempSaldo = Integer.parseInt(inputSaldo.getText().toString());
        }
        if(tempSaldo>=5000 && !inputNombre.getText().toString().equals("") && !inputRut.getText().toString().equals("")){
            String tempNombre = inputNombre.getText().toString();
            String tempRut = inputRut.getText().toString();
            inputNombre.setVisibility(View.GONE);
            inputRut.setVisibility(View.GONE);
            txtLabel.setVisibility(View.GONE);
            btnGuardar.setVisibility(View.GONE);
            inputSaldo.setVisibility(View.GONE);

            this.user = new Usuario(tempNombre, tempRut, tempSaldo);
            txtNombre.setText(user.getNombre());
            txtRut.setText(user.getRut());
            txtLabel2.setText("TARJETA REGISTRADA");

        }else if(tempSaldo<5000){
            Toast.makeText(this, "El valor del saldo tiene que ser mayor o igual a 5.000", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Rellene todos los campos, por favor, poyo", Toast.LENGTH_SHORT).show();
        }




    }

    public void devolver(View view) {
        Intent actividadabrirmenu= new Intent(this, MainActivity.class);
        actividadabrirmenu.putExtra("usuario", this.user);
        startActivity(actividadabrirmenu);
    }
}