package com.example.proyectochip;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class pagarPasaje extends AppCompatActivity {
    TextView txtsaldopasaje;
    RadioButton radiotaxi, radiometro;
    RadioGroup rgroup;
    Usuario user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pagar_pasaje);

        txtsaldopasaje = findViewById(R.id.txtsaldopasaje);
        radiotaxi = findViewById(R.id.radiotaxi);
        radiometro = findViewById(R.id.radiometro);
        rgroup = findViewById(R.id.radiogrop);

        user = (Usuario) getIntent().getSerializableExtra("usuario");
        txtsaldopasaje.setText("$"+user.getTarjeta().getSaldo());

    }

    public void pagarPasaje(View view){
        if(rgroup.getCheckedRadioButtonId() == -1){
            Toast.makeText(this, "Seleccione un medio de transporte, asopao", Toast.LENGTH_SHORT).show();
        }else{

            if(radiotaxi.isChecked()){
                if(user.getTarjeta().getSaldo()<1200){
                    Toast.makeText(this, "No te alcanza la plata po gil", Toast.LENGTH_SHORT).show();
                }else{
                    Registros viaje = new Registros(Calendar.getInstance().getTime(), "Taxi", 1200);
                    this.user.getTarjeta().agregarViaje(viaje);
                    Toast.makeText(this, "Pasaje pagado, disfruta mirando el taximetro.", Toast.LENGTH_SHORT).show();
                    devolver(view);
                }
            }else{
                if(user.getTarjeta().getSaldo()<8000){
                    Toast.makeText(this, "No te alcanza la plata po gil", Toast.LENGTH_SHORT).show();
                }else{
                    Registros viaje = new Registros(Calendar.getInstance().getTime(), "Metro", 8000);
                    this.user.getTarjeta().agregarViaje(viaje);
                    Toast.makeText(this, "Pasaje pagado, disfruta el olor a pata del metro.", Toast.LENGTH_SHORT).show();
                    devolver(view);
                }
            }
        }
    }

    public void devolver(View view){
        Intent actividad = new Intent(this, MainActivity.class);
        actividad.putExtra("usuario", this.user);
        startActivity(actividad);
    }


}
