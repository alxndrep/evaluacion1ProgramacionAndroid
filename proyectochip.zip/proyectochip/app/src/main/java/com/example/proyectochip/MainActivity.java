package com.example.proyectochip;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView txtnombre;
    TextView txtsaldo;
    Usuario user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtnombre = findViewById(R.id.txtNombreuser);
        txtsaldo = findViewById(R.id.txtSaldouser);
        user = (Usuario) getIntent().getSerializableExtra("usuario");
        if(user != null){
            txtnombre.setText(user.getNombre());
            int saldo = user.getTarjeta().getSaldo();
            txtsaldo.setText("SALDO: $"+saldo);
        }

    }

    public void Abrirtarjetita(View view) {
        Intent actividadabrirtarjeta = new Intent(this, Abrir_Tarjeta.class);
        startActivity(actividadabrirtarjeta);
    }
    public void AbrirRecarga(View view) {
        if(user != null){
            Intent actividad = new Intent(this, RecargarTarjeta.class);
            actividad.putExtra("usuario", this.user);
            startActivity(actividad);
        }else{
            Toast.makeText(this, "Primero crea tu tarjeta, sopenco calzonudo", Toast.LENGTH_SHORT).show();
        }
        
    }
    public void AbrirPago(View view) {
        if(user != null){
            Intent actividad = new Intent(this, pagarPasaje.class);
            actividad.putExtra("usuario", this.user);
            startActivity(actividad);
        }else{
            Toast.makeText(this, "Primero crea tu tarjeta, sopenco calzonudo", Toast.LENGTH_SHORT).show();
        }

    }
    public void VerHistorial(View view) {
        if(user != null){
            Intent actividad = new Intent(this, VerHistorial.class);
            actividad.putExtra("usuario", this.user);
            startActivity(actividad);
        }else{
            Toast.makeText(this, "Primero crea tu tarjeta, sopenco calzonudo", Toast.LENGTH_SHORT).show();
        }

    }
    
    
    
}