package com.example.proyectochip;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class Chip implements Serializable {

    private int saldo;
    private int numeroSerie;
    private ArrayList<Registros> historial;


    public Chip(int saldo) {
        this.saldo = saldo;
        Random rand = new Random();
        this.numeroSerie = rand.nextInt(100000) + 1280 ;
        this.historial = new ArrayList<Registros>();
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(int numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public ArrayList<Registros> getHistorial() {
        return historial;
    }

    public void setHistorial(ArrayList<Registros> historial) {
        this.historial = historial;
    }

    public void recargarSaldo(int monea){
        this.saldo += monea;
    }
    public void agregarViaje(Registros viaje){
        this.historial.add(viaje);
        this.saldo -= viaje.getValorPasaje();
    }
}
