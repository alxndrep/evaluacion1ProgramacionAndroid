package com.example.proyectochip;

import java.io.Serializable;

public class Usuario implements Serializable {

    private String nombre;
    private String rut;
    private Chip  tarjeta;

    public Usuario() {
        nombre = "";
        rut = "";
        tarjeta = null;
    }

    public Usuario(String nombre, String rut, int saldo) {
        this.nombre = nombre;
        this.rut = rut;
        this.tarjeta = new Chip(saldo);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public Chip getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(Chip tarjeta) {
        this.tarjeta = tarjeta;
    }
}
