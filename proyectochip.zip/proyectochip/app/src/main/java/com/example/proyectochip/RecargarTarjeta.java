package com.example.proyectochip;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EdgeEffect;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RecargarTarjeta extends AppCompatActivity {

    EditText saldorecarga;
    TextView saldoactual;
    Button btnRecargar;
    Usuario user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recargar_tarjeta);


        saldorecarga = findViewById(R.id.inputRecarga);
        saldoactual = findViewById(R.id.txtsaldo);
        btnRecargar = findViewById(R.id.btnRecargasaldo);

        user = (Usuario) getIntent().getSerializableExtra("usuario");
        saldoactual.setText("$"+user.getTarjeta().getSaldo());

    }
    public void recargarSaldo(View view){
        int tempRecarg;
        if(saldorecarga.getText().toString().equals("")){
            tempRecarg = 0;
        }else{
            tempRecarg = Integer.parseInt(saldorecarga.getText().toString());
        }

        if(tempRecarg >= 1000){
            user.getTarjeta().recargarSaldo(tempRecarg);
            saldoactual.setText("$"+user.getTarjeta().getSaldo());
            Toast.makeText(this, "Recarga realizada!, disfruta tus chauchas", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Solo recargas arriba de $1.000", Toast.LENGTH_SHORT).show();
        }
    }
    public void devolver(View view){
        Intent actividadabrirmenu= new Intent(this, MainActivity.class);
        actividadabrirmenu.putExtra("usuario", this.user);
        startActivity(actividadabrirmenu);
    }


}