package com.example.proyectochip;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class AdaptadorRegistros extends RecyclerView.Adapter<AdaptadorRegistros.ViewHolder> {

    private ArrayList<Registros> registros;
    public AdaptadorRegistros(ArrayList<Registros> registros) { this.registros = registros;}

    @NonNull
    @Override
    public AdaptadorRegistros.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.viaje, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorRegistros.ViewHolder holder, int position) {
        holder.transporte.setText(registros.get(position).getTipoTransporte());
        holder.monto.setText("$"+registros.get(position).getValorPasaje());
        holder.codigoserie.setText("ID: "+registros.get(position).getCodigoSerie());
        holder.fecha.setText("Fecha: "+registros.get(position).getHora());
    }

    @Override
    public int getItemCount() {
        return registros.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder{
        private TextView transporte, monto, codigoserie, fecha;

        public ViewHolder(View itemView){
            super(itemView);
            transporte = itemView.findViewById(R.id.txtTransporte);
            monto = itemView.findViewById(R.id.txtMonto);
            codigoserie = itemView.findViewById(R.id.txtCodigoserie);
            fecha = itemView.findViewById(R.id.txtFecha);
        }
    }
}
